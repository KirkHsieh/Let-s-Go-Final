﻿SET FOREIGN_KEY_CHECKS = 0;

DROP TABLE IF EXISTS  `attender`;
CREATE TABLE `attender` (
  `user_id` varchar(30) COLLATE utf8_bin NOT NULL,
  `trip_id` bigint(20) unsigned NOT NULL,
  `relationship` varchar(10) COLLATE utf8_bin NOT NULL,
  `date` datetime NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `trip_id` (`trip_id`),
  CONSTRAINT `attender_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `attender_ibfk_2` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS  `comment`;
CREATE TABLE `comment` (
  `comment_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` varchar(30) COLLATE utf8_bin NOT NULL,
  `trip_id` bigint(20) unsigned NOT NULL,
  `context` varchar(1000) COLLATE utf8_bin NOT NULL,
  PRIMARY KEY (`comment_id`),
  KEY `user_id` (`user_id`),
  KEY `trip_id` (`trip_id`),
  CONSTRAINT `comment_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `comment_ibfk_2` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS  `subscribe`;
CREATE TABLE `subscribe` (
  `user_id` varchar(30) COLLATE utf8_bin NOT NULL,
  `sub_id` varchar(30) COLLATE utf8_bin NOT NULL,
  `date` datetime NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `sub_id` (`sub_id`),
  CONSTRAINT `subscribe_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `subscribe_ibfk_2` FOREIGN KEY (`sub_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS  `rating`;
CREATE TABLE `rating` (
  `user_id` varchar(30) COLLATE utf8_bin NOT NULL,
  `trip_id` bigint(20) unsigned NOT NULL,
  `star` tinyint(4) NOT NULL,
  KEY `user_id` (`user_id`),
  KEY `trip_id` (`trip_id`),
  CONSTRAINT `rating_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`user_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `rating_ibfk_2` FOREIGN KEY (`trip_id`) REFERENCES `trip` (`trip_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS  `trip`;
CREATE TABLE `trip` (
  `trip_id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) COLLATE utf8_bin NOT NULL DEFAULT '',
  `place` varchar(100) COLLATE utf8_bin NOT NULL DEFAULT '',
  `tag` varchar(1000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `context` varchar(1000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `startDate` datetime NOT NULL,
  `endDate` datetime NOT NULL,
  `attendable` tinyint(1) NOT NULL,
  `completed` tinyint(1) NOT NULL,
  `rank` int(11) NOT NULL,
  `photo` blob NOT NULL,
  PRIMARY KEY (`trip_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

DROP TABLE IF EXISTS  `user`;
CREATE TABLE `user` (
  `user_id` varchar(30) COLLATE utf8_bin NOT NULL COMMENT 'FB',
  `name` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'FB',
  `location` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'FB',
  `email` varchar(30) COLLATE utf8_bin NOT NULL DEFAULT '',
  `personality` varchar(1000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `hobby` varchar(1000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `introduction` varchar(1000) COLLATE utf8_bin NOT NULL DEFAULT '',
  `privacy` int(11) DEFAULT '0' COMMENT 'todo',
  `picture` varchar(300) COLLATE utf8_bin NOT NULL DEFAULT '' COMMENT 'todo',
  `level` int(11) NOT NULL DEFAULT '1',
  `date` datetime NOT NULL,
  PRIMARY KEY (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

SET FOREIGN_KEY_CHECKS = 1;

